//
// Questo file è stato generato dall'architettura JavaTM per XML Binding (JAXB) Reference Implementation, v2.2.8-b130911.1802 
// Vedere <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Qualsiasi modifica a questo file andrà persa durante la ricompilazione dello schema di origine. 
// Generato il: 2017.04.24 alle 12:34:54 PM CEST 
//

@javax.xml.bind.annotation.XmlSchema(namespace = "urn:oasis:names:tc:xacml:3.0:core:schema:wd-17", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package oasis.names.tc.xacml.core.schema.wd_17;
